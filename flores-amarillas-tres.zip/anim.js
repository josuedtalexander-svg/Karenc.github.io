// Sincronizar las letras con la canción
var audio = document.querySelector("audio");
var lyrics = document.querySelector("#lyrics");

// Array de objetos que contiene cada línea y su tiempo de aparición en segundos
var lyricsData = [
  { text: "Rayando el sol", time: 19 },
  { text: "Rayando por ti", time: 21 },
  { text: "Esta pena me duele", time: 27 },
  { text: "Me quema sin tu amor", time: 28 },
  { text: "No me has llamado", time: 36 },
  { text: "Estoy desesperado", time: 37 },
  { text: "Son muchas lunas las que te he llorado", time: 44 },
  { text: "Rayando el sol", time: 51 },
  { text: "Desesperación", time: 55 },
  { text: "Es mas facil llegar al sol", time: 60 },
  { text: "Que a tu corazón", time: 65 },
  { text: "Me muero por ti", time: 69 },
  { text: "Viviendo sin ti", time: 71 },
  { text: "Y no aguanto", time: 74 },
  { text: "Me duele tanto estar asi", time: 78 },
  { text: "Rayando el sol", time: 85 },
  { text: "A tu casa yo fui", time: 90 },
  { text: "Y no te encontre", time: 95 },
  { text: "En el parque, en la plaza, en el cine", time: 100 },
  { text: "Yo te busque", time: 102 },
  { text: "te tengo atrapada entre mi piel y mi alma", time: 105 },
  { text: "Mas ya no puedo tanto", time: 116 },
  { text: "Y quiero estar junto a ti", time: 118 },
  { text: "Rayando el sol", time: 125 },
  { text: "Desesperación", time: 129 },
  { text: "Es mas facil llegar al sol", time: 133 },
  { text: "Aun asi me gustas Karen <3", time: 138 },
];

// Animar las letras
function updateLyrics() {
  var time = Math.floor(audio.currentTime);
  var currentLine = lyricsData.find(
    (line) => time >= line.time && time < line.time + 6
  );

  if (currentLine) {
    // Calcula la opacidad basada en el tiempo en la línea actual
    var fadeInDuration = 0.1; // Duración del efecto de aparición en segundos
    var opacity = Math.min(1, (time - currentLine.time) / fadeInDuration);

    // Aplica el efecto de aparición
    lyrics.style.opacity = opacity;
    lyrics.innerHTML = currentLine.text;
  } else {
    // Restablece la opacidad y el contenido si no hay una línea actual
    lyrics.style.opacity = 0;
    lyrics.innerHTML = "";
  }
}

setInterval(updateLyrics, 1000);

//funcion titulo
// Función para ocultar el título después de 216 segundos
function ocultarTitulo() {
  var titulo = document.querySelector(".titulo");
  titulo.style.animation =
    "fadeOut 3s ease-in-out forwards"; /* Duración y función de temporización de la desaparición */
  setTimeout(function () {
    titulo.style.display = "none";
  }, 3000); // Espera 3 segundos antes de ocultar completamente
}

// Llama a la función después de 216 segundos (216,000 milisegundos)
setTimeout(ocultarTitulo, 216000);